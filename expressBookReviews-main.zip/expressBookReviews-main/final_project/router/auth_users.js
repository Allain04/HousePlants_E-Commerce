const express = require('express');
const jwt = require('jsonwebtoken');
const regd_users = express.Router();
let books = require("./booksdb.js"); // Your in-memory book database

// In-memory users
let users = {};

// ===== Helper Functions =====

// Check if a username exists
const isValid = (username) => {
  return username && users[username];
};

// Validate username and password
const authenticatedUser = (username, password) => {
  return users[username] && users[username].password === password;
};

// Middleware to check login and set username
const verifyLogin = (req, res, next) => {
  const username = req.session?.authorization?.username;
  if (!username) {
    return res.status(401).json({ message: "User not logged in" });
  }
  req.username = username; // Store for use in routes
  next();
};

// ===== Task 7: User Login =====
regd_users.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: "Username and password are required" });
  }

  if (authenticatedUser(username, password)) {
    const accessToken = jwt.sign(
      { username },
      "access", // Secret key
      { expiresIn: "1h" }
    );

    // Store session info
    req.session.authorization = { accessToken, username };

    return res.status(200).json({
      message: "Login successful",
      token: accessToken
    });
  } else {
    return res.status(401).json({ message: "Invalid login credentials" });
  }
});

// ===== Task 8: Add or Modify a Book Review =====
regd_users.put("/auth/review/:isbn", verifyLogin, (req, res) => {
  const isbn = req.params.isbn;
  const review = req.query.review; // Optional: could also use req.body.review
  const username = req.username;

  if (!books[isbn]) {
    return res.status(404).json({ message: "Book not found" });
  }

  if (!review) {
    return res.status(400).json({ message: "Review text is required" });
  }

  books[isbn].reviews[username] = review;

  return res.status(200).json({
    message: "Review added/updated successfully",
    reviews: books[isbn].reviews
  });
});

// ===== Task 9: Delete a Book Review =====
regd_users.delete("/auth/review/:isbn", verifyLogin, (req, res) => {
  const isbn = req.params.isbn;
  const username = req.username;

  if (!books[isbn]) {
    return res.status(404).json({ message: "Book not found" });
  }

  if (books[isbn].reviews[username]) {
    delete books[isbn].reviews[username];
    return res.status(200).json({ message: "Your review has been deleted successfully" });
  } else {
    return res.status(404).json({ message: "No review found for this user" });
  }
});

// ===== Module Exports =====
module.exports.authenticated = regd_users;
module.exports.users = users;
module.exports.isValid = isValid;
