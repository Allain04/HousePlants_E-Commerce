const express = require('express');
const books = require("./booksdb.js");
const { isValid, users } = require("./auth_users.js");
const public_users = express.Router();
const axios = require('axios');
const BASE_URL = 'http://localhost:5000'; // Adjust if your server runs on another port

// ===== Register a new user =====
public_users.post("/register", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: "Username and password are required" });
  }

  if (users[username]) {
    return res.status(409).json({ message: "Username already exists" });
  }

  users[username] = { username, password };
  return res.status(200).json({ message: "User successfully registered. You can now log in." });
});

// ===== Task 10: Get all available books =====
public_users.get('/', (req, res) => {
  try {
    return res.status(200).json(books);
  } catch (error) {
    console.error("Error fetching books:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
});

// ===== Get book details based on ISBN =====
public_users.get('/isbn/:isbn', (req, res) => {
  const { isbn } = req.params;
  const book = books[isbn];

  if (book) {
    return res.status(200).json(book);
  }
  return res.status(404).json({ message: "Book not found" });
});

// ===== Get book details based on author =====
public_users.get('/author/:author', (req, res) => {
  const author = req.params.author.toLowerCase();
  const matchingBooks = Object.values(books).filter(
    book => book.author.toLowerCase() === author
  );

  if (matchingBooks.length > 0) {
    return res.status(200).json(matchingBooks);
  }
  return res.status(404).json({ message: "No books found for this author" });
});

// ===== Get book details based on title =====
public_users.get('/title/:title', (req, res) => {
  const title = req.params.title.toLowerCase();
  const matchingBooks = Object.values(books).filter(
    book => book.title.toLowerCase() === title
  );

  if (matchingBooks.length > 0) {
    return res.status(200).json(matchingBooks);
  }
  return res.status(404).json({ message: "No books found with this title" });
});

// ===== Get book reviews by ISBN =====
public_users.get('/review/:isbn', (req, res) => {
  const { isbn } = req.params;

  if (books[isbn]) {
    return res.status(200).json(books[isbn].reviews);
  }
  return res.status(404).json({ message: "Book not found" });
});

module.exports.general = public_users;

// ===== Task 11: Fetch book by ISBN using async/await =====
async function getBookByISBN(isbn) {
  try {
    const response = await axios.get(`${BASE_URL}/isbn/${isbn}`);
    console.log(`Task 11: Details of book with ISBN ${isbn}:`);
    console.log(response.data);
  } catch (error) {
    if (error.response) {
      console.error(`Error: ${error.response.status} - ${error.response.data.message}`);
    } else if (error.request) {
      console.error("No response received from server:", error.request);
    } else {
      console.error("Error fetching book by ISBN:", error.message);
    }
  }
}

// ===== Task 12: Fetch books by author using async/await =====
async function getBooksByAuthor(author) {
  try {
    const response = await axios.get(`${BASE_URL}/author/${encodeURIComponent(author)}`);
    console.log(`Task 12: Books by author "${author}":`);
    console.log(response.data);
  } catch (error) {
    if (error.response) {
      console.error(`Error: ${error.response.status} - ${error.response.data.message}`);
    } else if (error.request) {
      console.error("No response received from server:", error.request);
    } else {
      console.error("Error fetching books by author:", error.message);
    }
  }
}

// ===== Task 13: Fetch books by title using async/await =====
async function getBooksByTitle(title) {
  try {
    const response = await axios.get(`${BASE_URL}/title/${encodeURIComponent(title)}`);
    console.log(`Task 13: Books with title "${title}":`);
    console.log(response.data);
  } catch (error) {
    if (error.response) {
      console.error(`Error: ${error.response.status} - ${error.response.data.message}`);
    } else if (error.request) {
      console.error("No response received from server:", error.request);
    } else {
      console.error("Error fetching books by title:", error.message);
    }
  }
}

// ===== Example usages =====
getBookByISBN(1);                    // Task 11 example
getBooksByAuthor("Chinua Achebe");   // Task 12 example
getBooksByTitle("Things Fall Apart"); // Task 13 example